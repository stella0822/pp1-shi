/* File: dppmain.cc
 * ----------------
 * This file defines the main() routine for the preprocessor, 
 * the filtering tool which runs before the compiler.
 */

#include "scanner.h"
#include <stdio.h>
#include "errors.h"
#include "hash_table.cc"

#define MAX_LENGTH 31

/* Function: main()
 * ----------------
 * Entry point to the preprocessor.
 * As given below, this "filter" just copies stdin to stdout unchanged.
 * It will be your job to actually do some filtering, either by hand-coded
 * transformation of the input or by setting up a lex scanner in the dpp.l
 * file and changing the main below to invoke it via yylex. When finished,
 * the preprocessor should echo stdin to stdout making the transformations
 * to strip comments and handle preprocessor directives.
 */
int main(int argc, char *argv[])
{
    int ch;
    int ch2, ch3;  //temp variable
    
    int lineNum=1;
    
    ReportError rError;

    hash_map<const char*, string>hashTableDir; 
    //unorderedhash_map<const char*, string>hashTableDir;

    ch=getc(stdin);
   
  while (ch != EOF){
      if(ch=='/'){  //start with '/' means there may be some comments
          ch2=getc(stdin);
          if(ch2=='/'){  //the content after "//" is a single-line comment
              ch2=getc(stdin);
              while(ch2!='\n'){  //'\n'is the end of a single-line comment
                  putc(' ', stdout);
                  ch2=getc(stdin);
              }
              putc(ch2, stdout);
              lineNum++;
          }
          
          else if(ch2=='*'){  //the content after "/*" are multi-line comments
              ch2=getc(stdin);
              if(ch2!=EOF){
                  ch3=getc(stdin);
                  while((ch2!='*' || ch3!='/') && ch3!=EOF){  //the end of multi-line comments is "*/"
                      if(ch2=='\n'){
                          putc(ch2,stdout);
                          lineNum++;
                      }
                      ch2=ch3;
                      ch3=getc(stdin);
                  }
                  if(ch3==EOF){  //if the file ends without "*/", we should report an error.
                      rError.UntermComment();
                  }
              }
              else{  //if the file ends without "*/", we should report an error.
                  rError.UntermComment();
              }
          }

         else{
               putc(ch, stdout);
               putc(ch2, stdout);
         }
      }
      
      else if(ch=='#'){  //start with '#' means there is "#define" or "#NAME"
          ch2=getc(stdin);
          string str1="", str2="", str3="";  //str2 for NAME, and str3 for replacement
          while (ch2!=' ') {  //read the word after '#'
              str1+=ch2;
              ch2=getc(stdin);
          }
          cout<<"here-"<<str1<<"-end"<<endl;//
        
          int temp=0;
          if (str1.compare("define")==0) {  //it is a macro definition
              ch2=getc(stdin);
              while (ch2!=' ') {  //read NAME
                  temp=0;
                  if ((ch2-'A'>=0)&&('Z'-ch2>=0)) {
                      str2+=ch2;  //put NAME in the variable str2
                      ch2=getc(stdin);
                  }
                  else {
                      rError.InvalidDirective(lineNum);
                      ch2=getc(stdin);
                      while (ch2!='\n') {
                          ch2=getc(stdin);
                      }
                      lineNum++;
                      temp=1;
                  }
              }

              if (!temp) {
                  ch2=getc(stdin);
                  while (ch2!='\n') {  //read replacement
                      str3+=ch2;  //put replacement in the variable str3
                      ch2=getc(stdin);
                  }
                  lineNum++;

cout<<str2<<endl;
cout<<str3<<endl;
                  hashTableDir.insert(pair<const char*, string>(str2.c_str(), str3));//keep str2 and str3 into the table
cout<<hashTableDir[str2.c_str()]<<endl;
hash_map<const char*, string>::iterator itt2=hashTableDir.begin();
int limit=0;
while(itt2!=hashTableDir.end()&&limit<20){
cout<<itt2->first<<'\t'<<itt2->second<<endl;
itt2++;
  limit++;
}
              }
          }
          else{  //it is a NAME to be replaced
              if(hashTableDir.find(str1.c_str())==hashTableDir.end()){
                  rError.InvalidDirective(lineNum);
              }
              else{
                  cout<<hashTableDir[str1.c_str()]<<endl;//read the replacement of NAME from the table 
              }
          }
      }
      
      else{
          if(ch=='\n'){
              lineNum++;
          }
          putc(ch, stdout);
      }
    ch=getc(stdin);
  }

  return 0;
}
